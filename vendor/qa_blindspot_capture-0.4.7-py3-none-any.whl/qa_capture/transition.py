"""Bounded XML observation, never a customer assertion or readiness guarantee."""
import hashlib
import time


def xml_digest(value):
    if not isinstance(value, str) or not value.strip():
        return None
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


def observe_xml(read_xml, baseline, budget_seconds, *, clock=time.monotonic,
                sleep=time.sleep, interval=.25, max_reads=6):
    started = clock()
    deadline = started + budget_seconds
    previous = None
    changed = False
    result = {'status': 'budget_reached', 'reads': 0, 'changed': False}
    for _ in range(max_reads):
        remaining = deadline - clock()
        if remaining < interval:
            break
        sleep(interval)
        if clock() >= deadline:
            break
        try:
            current = xml_digest(read_xml())
        except Exception:
            result['status'] = 'xml_unavailable'
            break
        result['reads'] += 1
        if current is None:
            result['status'] = 'xml_unavailable'
            break
        changed = changed or (baseline is not None and current != baseline)
        # Equal XML samples are evidence of repetition, not page readiness.
        if changed and current == previous and clock() - started >= .5:
            result['status'] = 'changed_then_repeated_xml'
            break
        previous = current
    result.update(changed=changed, elapsed_seconds=round(clock() - started, 6))
    return result
