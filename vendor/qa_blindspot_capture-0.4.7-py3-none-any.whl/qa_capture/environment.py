"""Small reproducibility metadata allowlist. No environment, URLs or capabilities dump."""
from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version
import platform
import subprocess


def runtime_metadata():
    result = {'python': platform.python_version(), 'platform': platform.system()}
    for key, package in [('pytest', 'pytest'), ('selenium', 'selenium'), ('appium', 'Appium-Python-Client')]:
        try:
            result[key] = version(package)
        except PackageNotFoundError:
            result[key] = 'unknown'
    return result


def code_metadata(root):
    result = {'status': 'unavailable', 'commit': None, 'tracked_dirty': None}
    try:
        commit = subprocess.run(['git', '-C', str(root), 'rev-parse', '--verify', 'HEAD'],
                                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=1,
                                text=True, check=False)
        value = commit.stdout.strip()
        if commit.returncode or len(value) not in (40, 64) or any(c not in '0123456789abcdef' for c in value):
            return result
        result.update(status='recorded', commit=value)
        # Only tracked modifications; untracked files and repository URLs are not read.
        dirty = subprocess.run(['git', '-C', str(root), 'diff', '--quiet', 'HEAD', '--'],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=1,
                               check=False)
        if dirty.returncode in (0, 1):
            result['tracked_dirty'] = bool(dirty.returncode)
    except (OSError, subprocess.TimeoutExpired):
        pass
    return result


def device_metadata(driver):
    state = getattr(driver, '__dict__', {})
    caps = state.get('caps', state.get('capabilities', {})) if type(state) is dict else {}
    if type(caps) is not dict:
        caps = {}
    aliases = {
        'device_name': ('appium:deviceName', 'deviceName'),
        'platform': ('platformName',),
        'os_version': ('appium:platformVersion', 'platformVersion'),
        'automation_name': ('appium:automationName', 'automationName'),
        'app_package': ('appium:appPackage', 'appPackage', 'appium:bundleId', 'bundleId'),
        'app_version': ('appium:appVersion', 'appVersion', 'appium:versionName', 'versionName'),
        'app_build': ('appium:versionCode', 'versionCode', 'appium:appBuild', 'appBuild'),
    }
    result = {'metadata_source': 'session_capabilities', 'missing': []}
    for key, names in aliases.items():
        val = next((caps[name] for name in names if type(caps.get(name)) in (str, int) and caps[name] != ''), None)
        if val is None:
            result['missing'].append(key)
        else:
            result[key] = str(val)[:200]
    return result
