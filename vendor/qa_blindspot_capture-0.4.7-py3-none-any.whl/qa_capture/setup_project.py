"""Explicit, conservative project setup; importing/installing the wheel never edits files."""
from __future__ import annotations
import configparser
from datetime import datetime
import os
from pathlib import Path
import re
import shutil
import stat
import tempfile
import tomllib


def read_config(path):
    text = path.read_text(encoding='utf-8-sig')
    if path.name == 'pyproject.toml':
        return tomllib.loads(text).get('tool', {}).get('pytest', {}).get('ini_options')
    parser = configparser.ConfigParser(interpolation=None)
    parser.read_string(text)
    section = 'tool:pytest' if path.name == 'setup.cfg' else 'pytest'
    if parser.has_section(section):
        return dict(parser[section])
    if path.name in ('pytest.ini', '.pytest.ini'):
        return {}
    return None


def locate(root):
    # Native pytest TOML has different semantics; never create a shadowing ini.
    for name in ('pytest.toml', '.pytest.toml'):
        if (root/name).exists():
            raise ValueError(f'{name}: native pytest TOML is not supported by automatic setup; use pytest.ini or configure manually.')
    for name in ('pytest.ini', '.pytest.ini', 'pyproject.toml', 'tox.ini', 'setup.cfg'):
        path = root/name
        try:
            info=path.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode) or getattr(info,'st_file_attributes',0)&0x400:
            raise ValueError(f'Refusing symlink/reparse configuration: {path}')
        if path.is_file():
            values = read_config(path)
            if values is not None:
                return path, values
    return None, {}


def _patch(text, section, values, toml=False):
    lines = text.splitlines(keepends=True)
    nl = '\r\n' if '\r\n' in text else '\n'
    heading = re.compile(r'^\s*\[' + re.escape(section) + r'\]\s*(?:[#;].*)?$')
    start = next((i for i,line in enumerate(lines) if heading.match(line.strip())), None)
    if start is None:
        if text and not text.endswith(('\n','\r')): lines.append(nl)
        if lines: lines.append(nl)
        lines.append(f'[{section}]'+nl)
        start = len(lines)-1
    end = next((i for i in range(start+1,len(lines)) if lines[i].lstrip().startswith('[')),len(lines))
    for key,value in values.items():
        pattern = re.compile(r'^\s*'+re.escape(key)+r'\s*=')
        indices = [i for i in range(start+1,end) if pattern.match(lines[i])]
        if len(indices)>1: raise ValueError(f'Duplicate configuration key: {key}')
        rendered = ('true' if value is True else 'false') if isinstance(value,bool) else (('"'+value+'"') if toml else value)
        replacement = f'{key} = {rendered}'+nl
        if indices:
            i=indices[0]
            # Never guess where a multiline customer's value ends.
            if (toml and any(mark in lines[i] for mark in ('"""', "'''", '['))) or (
                not toml and i+1<end and lines[i+1][:1].isspace() and lines[i+1].strip()
                and not lines[i+1].lstrip().startswith(('#',';'))):
                raise ValueError(f'Multiline {key}: configure this value manually.')
            lines[i]=replacement
        else:
            if end and not lines[end-1].endswith(('\n','\r')):lines[end-1]+=nl
            lines.insert(end,replacement);end+=1
    return ''.join(lines)


def initialize(project, *, sources=None, driver_fixture=None):
    root=Path(project).expanduser().resolve()
    if not root.is_dir(): raise ValueError('Project directory does not exist.')
    if not (root/'tests').is_dir() and not (root/'test').is_dir() and not (root/'conftest.py').is_file() and not any(root.glob('test_*.py')):
        raise ValueError('Select the pytest project root (tests/, test/, conftest.py or test_*.py required).')
    path,current=locate(root)
    if path is None:
        for parent in root.parents:
            ancestor,_=locate(parent)
            if ancestor: raise ValueError(f'Parent pytest configuration exists: {ancestor}. Select the actual project root.')
        path=root/'pytest.ini'
    desired={'qa_capture':True,'enable_assertion_pass_hook':True}
    if sources is not None: desired['qa_capture_sources']=sources
    elif 'qa_capture_sources' not in current: desired['qa_capture_sources']=False
    if driver_fixture is not None:
        if not re.fullmatch(r'[A-Za-z_]\w*(?:\s+[A-Za-z_]\w*)*',driver_fixture):
            raise ValueError('Driver fixture must contain Python names separated by spaces.')
        desired['qa_driver_fixture']=driver_fixture
    elif 'qa_driver_fixture' not in current: desired['qa_driver_fixture']='driver'
    def equal(old,new):
        return str(old).lower() in ('true','1','yes','on') if new is True else (
            str(old).lower() in ('false','0','no','off') if new is False else old==new)
    changes={k:v for k,v in desired.items() if k not in current or not equal(current[k],v)}
    original=path.read_bytes() if path.exists() else b''
    text=original.decode('utf-8-sig')
    section='tool.pytest.ini_options' if path.name=='pyproject.toml' else ('tool:pytest' if path.name=='setup.cfg' else 'pytest')
    updated=_patch(text,section,changes,toml=path.name=='pyproject.toml') if changes else text
    # Validate the complete edited document before touching the original.
    if path.name=='pyproject.toml':
        edited=tomllib.loads(updated).get('tool',{}).get('pytest',{}).get('ini_options',{})
    else:
        parser=configparser.ConfigParser(interpolation=None);parser.read_string(updated)
        edited=dict(parser[section])
    if any(k not in edited or not equal(edited[k],v) for k,v in desired.items()):
        raise ValueError('Configuration layout could not be safely updated; configure manually.')
    backup=None
    if changes:
        if path.exists():
            backup=path.with_name(path.name+'.qa-backup-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
            shutil.copy2(path,backup)
        payload=updated.encode('utf-8')
        if original.startswith(b'\xef\xbb\xbf'):payload=b'\xef\xbb\xbf'+payload
        fd,temp=tempfile.mkstemp(prefix='.qa-setup-',dir=root)
        try:
            with os.fdopen(fd,'wb') as stream:stream.write(payload)
            if path.exists():shutil.copymode(path,temp)
            os.replace(temp,path)
        finally:
            if os.path.exists(temp):os.unlink(temp)
    # pytest caches rewritten assertions. Invalidate only pytest-tagged bytecode,
    # never customer sources, ordinary pyc files, environments or symlink targets.
    removed=0; errors=[]
    if 'enable_assertion_pass_hook' in changes:
        for base,dirs,files in os.walk(root,followlinks=False):
            dirs[:]=[d for d in dirs if not d.startswith('.') and d not in ('venv','env','node_modules','qa-results','site-packages') and not Path(base,d).is_symlink()]
            if Path(base).name!='__pycache__':continue
            for name in files:
                p=Path(base,name)
                if re.search(r'-pytest-[^/]+\.pyc$',name) and not p.is_symlink():
                    try:p.unlink();removed+=1
                    except OSError as exc:errors.append(f'{p}: {exc}')
    return {'config':str(path),'changed':list(changes),'backup':str(backup) if backup else None,
            'pytest_cache_files_removed':removed,'warnings':errors,
            'next':'Run your usual python -m pytest command. Default driver fixture: driver unless configured otherwise.'}
