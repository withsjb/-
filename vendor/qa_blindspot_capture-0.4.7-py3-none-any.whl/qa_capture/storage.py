"""Exact-byte deduplication and independent, fair XML/image storage budgets."""
from collections import Counter
import hashlib


class EvidenceStorage:
    def __init__(self, total_bytes, max_asset_bytes, xml_percent=25):
        self.max_asset = max_asset_bytes
        xml = total_bytes * xml_percent // 100
        self.limits = {'xml': xml, 'image': total_bytes - xml}
        self.assets = {}
        self.used = {'xml': 0, 'image': 0}
        self.case_count = 1
        self.visit_used = {}
        self.reused = Counter()
        self.saved_bytes = 0
        self.omissions = []
        self.omission_counts = Counter()

    @property
    def total_bytes(self):
        return sum(self.used.values())

    def reject(self, row, kind, reason, size=None):
        self.omission_counts[(row['tc_id'], row['visit_id'], kind, reason)] += 1
        if len(self.omissions) < 2000:
            event = {k: row[k] for k in ('id', 'tc_id', 'visit_id', 'step_id', 'phase')}
            event.update(kind=kind, reason=reason)
            if size is not None:
                event['bytes'] = size
            self.omissions.append(event)
        return None, reason

    def save(self, row, suffix, data):
        kind = 'xml' if suffix == 'xml' else 'image'
        size = len(data)
        if size > min(self.max_asset, 2000000 if kind == 'xml' else self.max_asset):
            return self.reject(row, kind, 'asset_quota', size)
        path = 'assets/' + hashlib.sha256(data).hexdigest() + '.' + suffix
        # Reuse only bytes actually read NOW, never a cached prior screenshot.
        # A reference to an already stored file costs no new storage budget.
        if path in self.assets:
            self.reused[kind] += 1
            self.saved_bytes += size
            return path, None
        visit = self.visit_used.setdefault(row['visit_id'], {'xml': 0, 'image': 0})
        per_visit = self.limits[kind] // max(1, self.case_count)
        if visit[kind] + size > per_visit:
            return self.reject(row, kind, kind + '_tc_quota', size)
        if self.used[kind] + size > self.limits[kind]:
            return self.reject(row, kind, kind + '_pool_quota', size)
        self.assets[path] = data
        self.used[kind] += size
        visit[kind] += size
        return path, None

    def summary(self):
        return {'policy': 'exact_bytes_split_pool_equal_visit_budget',
                'selected_test_count': self.case_count, 'pool_limits': self.limits,
                'per_visit_limits': {k: v // max(1, self.case_count) for k, v in self.limits.items()},
                'stored_bytes': self.used, 'unique_files': len(self.assets),
                'reused_references': dict(self.reused), 'deduplicated_bytes': self.saved_bytes,
                'visit_stored_bytes': self.visit_used, 'omissions': self.omissions,
                'omission_counts': [dict(tc_id=k[0], visit_id=k[1], kind=k[2], reason=k[3], count=v)
                                    for k, v in self.omission_counts.items()]}
