"""A deliberately small assertion grammar. No eval or customer callable invocation."""
from __future__ import annotations

import ast
import builtins
import re


_ATTRS = {'resource-id': 'resource_id', 'content-desc': 'content_desc', 'text': 'text', 'class': 'class'}


def absence_assert(tree, frame, line, read):
    """Only a direct query or adjacent assignment in the SAME statement block.

    No arbitrary value provenance, lambda evaluation or customer callbacks.
    A nonempty remote response cannot become absence by clearing a local list.
    """
    if read.get('condition') != 'absent' or read.get('actual') is not True:
        return False
    nodes = [n for n in ast.walk(tree) if isinstance(n, ast.Assert) and n.lineno == line]
    if len(nodes) != 1:
        return False
    node = nodes[0].test
    if not (isinstance(node, ast.Compare) and len(node.ops) == 1
            and isinstance(node.ops[0], ast.Eq) and isinstance(node.comparators[0], ast.Constant)
            and type(node.comparators[0].value) is int and node.comparators[0].value == 0):
        return False
    call = node.left
    if not (isinstance(call, ast.Call) and isinstance(call.func, ast.Name)
            and call.func.id == 'len' and len(call.args) == 1 and not call.keywords
            and frame.f_locals.get('len', frame.f_globals.get('len', builtins.len)) is builtins.len
            and frame.f_builtins.get('len') is builtins.len):
        return False
    query = call.args[0]
    if isinstance(query, ast.Name):
        value = frame.f_locals.get(query.id)
        if type(value) is not list or value:
            return False
        previous = None
        for parent in ast.walk(tree):
            for _, block in ast.iter_fields(parent):
                if isinstance(block, list) and nodes[0] in block:
                    i = block.index(nodes[0])
                    if i:
                        previous = block[i - 1]
        if not (isinstance(previous, ast.Assign) and len(previous.targets) == 1
                and isinstance(previous.targets[0], ast.Name) and previous.targets[0].id == query.id
                and previous.lineno == read['line']):
            return False
        query = previous.value
    elif read['line'] != line:
        return False
    if not (isinstance(query, ast.Call) and isinstance(query.func, ast.Attribute)
            and query.func.attr == 'find_elements' and isinstance(query.func.value, ast.Name)
            and not query.keywords):
        return False
    receiver = frame.f_locals.get(query.func.value.id, frame.f_globals.get(query.func.value.id))
    # Restrict arguments so a nested callback cannot modify the query result.
    safe_arg = lambda a: isinstance(a, (ast.Name, ast.Constant)) or (
        isinstance(a, ast.Starred) and isinstance(a.value, ast.Name)) or (
        isinstance(a, ast.Attribute) and isinstance(a.value, ast.Name))
    return receiver is read['info']['driver'] and all(safe_arg(a) for a in query.args)


def selector(using, value, context):
    if not isinstance(value, str) or not value or len(value) > 2000:
        return None
    if using == 'id':
        return {'resource_id': value} if context == 'native' else None
    if using == 'accessibility id':
        return {'content_desc': value} if context == 'native' else None
    if using != 'xpath' or context != 'native':
        return None
    match = re.fullmatch(r'//([\w.]+|\*)\[@([\w-]+)=(\"[^\"]*\"|\x27[^\x27]*\x27)\]', value)
    if not match or match[2] not in _ATTRS:
        return None
    target = {_ATTRS[match[2]]: match[3][1:-1]}
    if not all(target.values()):
        return None
    if match[1] != '*':
        target['class'] = match[1]
    return target


def assertion_shape(expression, frame):
    """Return terminal operation/expected value, accepting no broad bool/helper grammar."""
    try:
        node = ast.parse(expression, mode='eval').body
    except (SyntaxError, ValueError, MemoryError, RecursionError):
        return None
    def receiver_safe(receiver):
        if isinstance(receiver, ast.Name):
            return True
        # An argument with another element read can leave unrelated evidence on the
        # same source line. Only a simple element-returning call is eligible.
        return (isinstance(receiver, ast.Call) and isinstance(receiver.func, (ast.Name, ast.Attribute))
                and all(isinstance(arg, (ast.Name, ast.Constant)) for arg in receiver.args)
                and all(k.arg and isinstance(k.value, (ast.Name, ast.Constant)) for k in receiver.keywords))
    if isinstance(node, ast.Call) and not node.args and not node.keywords and isinstance(node.func, ast.Attribute) and receiver_safe(node.func.value):
        condition = {'is_displayed': 'visible', 'is_enabled': 'enabled'}.get(node.func.attr)
        if condition:
            return condition, True
    if isinstance(node, ast.Compare) and len(node.ops) == 1 and isinstance(node.ops[0], ast.Eq):
        left, right = node.left, node.comparators[0]
        if isinstance(right, ast.Attribute) and right.attr == 'text':
            left, right = right, left
        if isinstance(left, ast.Attribute) and left.attr == 'text' and receiver_safe(left.value):
            if isinstance(right, ast.Constant) and type(right.value) is str and len(right.value) <= 20000:
                return 'text_equals', right.value
            if isinstance(right, ast.Name):
                value = frame.f_locals.get(right.id, frame.f_globals.get(right.id))
                if type(value) is str and len(value) <= 20000:
                    return 'text_equals', value
    return None


def context_kind(value):
    if value == 'NATIVE_APP':
        return 'native'
    if isinstance(value, str) and value.startswith('WEBVIEW'):
        return 'webview'
    return 'unknown'


def element_id(value):
    if isinstance(value, dict):
        return value.get('element-6066-11e4-a52e-4f735466cecf') or value.get('ELEMENT')
    # No properties or arbitrary customer descriptors are accessed here.
    state = getattr(value, '__dict__', None)
    return state.get('_id') if type(state) is dict else None
