"""Opt-in pytest entry point. Disabled installations do no capture or output."""
from __future__ import annotations

import pytest


def pytest_addoption(parser):
    parser.addini('qa_capture', 'Enable local QA evidence capture', type='bool', default=False)
    parser.addini('qa_driver_fixture', 'Whitespace-separated driver fixture names', type='args', default=['driver'])
    parser.addini('qa_app_version', 'Optional declared app version (not device-observed)', default='')
    parser.addini('qa_app_build', 'Optional declared app build (not device-observed)', default='')
    parser.addini('qa_capture_sources', 'Include executed test-function source excerpts', type='bool', default=False)
    parser.addini('qa_capture_output', 'Project-relative output folder', default='qa-results')
    parser.addini('qa_capture_transition_ms', 'Post-click/Back XML observation budget in milliseconds (0 disables)', default='1500')
    parser.addini('qa_capture_transition_tc_ms', 'Total post-click/Back XML observation budget per TC in milliseconds', default='4000')
    parser.addini('qa_capture_max_snapshots', 'Maximum captures per TC execution', default='24')
    parser.addini('qa_capture_max_asset_bytes', 'Maximum individual attachment bytes', default='8000000')
    parser.addini('qa_capture_xml_budget_percent', 'Reserved XML percentage of total bytes; images use the rest', default='25')
    parser.addini('qa_capture_max_total_bytes', 'Maximum total attachment bytes', default='32000000')


def pytest_configure(config):
    if not config.getini('qa_capture') or getattr(config.option, 'collectonly', False):
        return
    workers = getattr(config.option, 'numprocesses', None)
    if hasattr(config, 'workerinput') or workers not in (None, 0, '0'):
        raise pytest.UsageError('QA capture 0.4: parallel xdist runs are unsupported; run without -n.')
    if getattr(config.option, 'reruns', 0):
        raise pytest.UsageError('QA capture 0.4: in-process automatic reruns are unsupported; run each attempt separately.')
    from .recorder import Recorder
    recorder = Recorder(config)
    config.pluginmanager.register(recorder, 'qa_capture_recorder')


def pytest_collection_modifyitems(config, items):
    if config.getini('qa_capture') and any(item.get_closest_marker('flaky') for item in items):
        raise pytest.UsageError('QA capture 0.4: flaky/rerun markers are unsupported; use separate pytest runs.')
