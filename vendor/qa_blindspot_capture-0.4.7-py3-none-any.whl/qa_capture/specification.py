"""Bounded, exact-ID TC specifications. Declarations never become passed checks."""
from __future__ import annotations
import csv
import hashlib
import io
import os
from pathlib import Path
import stat

from .observation_log import log_path

MAX_BYTES = 1_000_000
FIELDS = ('tc_id', 'title', 'depth1', 'depth2', 'depth3', 'steps', 'expected', 'scope')
ALIASES = {
    'tc_id': ('tc_id', 'tc id', 'tcid', 'tc번호', 'tc 번호', 'id'),
    'title': ('title', '제목', 'tc명', '테스트명'),
    'depth1': ('depth1', 'depth 1', 'depth_1', '대분류'),
    'depth2': ('depth2', 'depth 2', 'depth_2', '중분류'),
    'depth3': ('depth3', 'depth 3', 'depth_3', '소분류'),
    'steps': ('steps', 'step', '절차', '수행절차', '수행 절차', '테스트 절차'),
    'expected': ('expected', 'expected result', 'expected_result', '예상 결과', '예상결과', '기대결과', '기대 결과'),
    'scope': ('scope', '범위', '검토 범위'),
}


def parse(raw):
    if len(raw) > MAX_BYTES:
        raise ValueError('specification_size')
    text = raw.decode('utf-8-sig')
    if '\x00' in text:
        raise ValueError('specification_characters')
    reader = csv.DictReader(io.StringIO(text, newline=''), strict=True)
    headers = reader.fieldnames
    if (not headers or len(headers) > 50 or len(set(headers)) != len(headers)
            or any(not h.strip() or len(h) > 200 for h in headers)):
        raise ValueError('specification_headers')
    mapping = {}
    for header in headers:
        for field, aliases in ALIASES.items():
            if header.strip().lower() in aliases:
                if field in mapping.values():
                    raise ValueError('specification_duplicate_columns')
                mapping[header] = field
    if not {'tc_id', 'steps', 'expected'} <= set(mapping.values()):
        raise ValueError('specification_required_columns')
    cases = {}
    for n, raw_row in enumerate(reader):
        if n >= 1000 or None in raw_row or any(v is None or len(v) > 20000 for v in raw_row.values()):
            raise ValueError('specification_rows')
        row = {field: raw_row[header].strip() for header, field in mapping.items()}
        ident = row['tc_id']
        if (not ident or len(ident) > 160 or any(ord(c) < 32 or ord(c) == 127 for c in ident)
                or ident in cases or not row['steps'] or not row['expected']):
            raise ValueError('specification_identity_or_required_text')
        if any('\x00' in v or any(0xD800 <= ord(c) <= 0xDFFF for c in v) for v in row.values()):
            raise ValueError('specification_characters')
        row['title'] = row.get('title') or ' / '.join(row.get(k, '') for k in ('depth1', 'depth2', 'depth3') if row.get(k)) or ident
        if len(row['title']) > 1000:
            raise ValueError('specification_title')
        row['scope'] = row.get('scope') or 'in_scope'
        if row['scope'] not in ('in_scope', 'out_of_scope'):
            raise ValueError('specification_scope')
        row['requirements'] = []
        cases[ident] = row
    if not cases:
        raise ValueError('specification_empty')
    return cases


def load(root, selected):
    """Auto only checks two documented names; never searches arbitrary CSVs."""
    root = Path(root).resolve()
    if selected == 'off':
        return {}, {'status': 'disabled'}
    if selected == 'auto':
        candidates = [name for name in ('test_cases.csv', 'test_data/test_cases.csv') if (root/name).exists() or (root/name).is_symlink()]
        if not candidates:
            return {}, {'status': 'not_provided'}
        if len(candidates) != 1:
            raise ValueError('specification_ambiguous_paths')
        selected = candidates[0]
    if not selected or not isinstance(selected, str):
        raise ValueError('specification_path')
    path = log_path(root, configured=selected)
    if path is None or path.suffix.lower() != '.csv':
        raise ValueError('specification_path')
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_BINARY', 0))
    with os.fdopen(fd, 'rb') as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_BYTES:
            raise ValueError('specification_size_or_type')
        raw = stream.read(MAX_BYTES + 1)
    try:
        cases = parse(raw)
    except (csv.Error, UnicodeError) as exc:
        raise ValueError('specification_csv_format') from exc
    return cases, {'status': 'loaded', 'path': path.relative_to(root).as_posix(),
                   'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw), 'case_count': len(cases)}


def csv_bytes(cases):
    stream = io.StringIO(newline='')
    writer = csv.DictWriter(stream, fieldnames=FIELDS, extrasaction='ignore', lineterminator='\n')
    writer.writeheader()
    writer.writerows(cases)
    result = stream.getvalue().encode('utf-8-sig')
    if len(result) > MAX_BYTES:
        raise ValueError('specification_export_size')
    return result
