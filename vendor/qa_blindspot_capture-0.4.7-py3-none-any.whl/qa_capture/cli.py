"""Static installation/configuration diagnostic; never imports customer modules."""
from __future__ import annotations
import argparse
import configparser
import importlib.metadata
import json
from pathlib import Path
import tomllib
from . import __version__


def doctor(project):
    root = Path(project).expanduser().resolve()
    from .setup_project import locate
    try:
        selected_path, settings = locate(root)
        selected = selected_path.name if selected_path else None
    except Exception as exc:
        return {'version': __version__, 'ready': False, 'errors': [str(exc)]}
    enabled = str(settings.get('qa_capture', False)).lower() in ('true', '1', 'yes', 'on')
    hook = str(settings.get('enable_assertion_pass_hook', False)).lower() in ('true', '1', 'yes', 'on')
    entrypoint = any(ep.name == 'qa_capture' and ep.value == 'qa_capture.plugin'
                     for ep in importlib.metadata.entry_points(group='pytest11'))
    errors = []
    if not enabled:
        errors.append('Set qa_capture = true in pytest configuration.')
    if not hook:
        errors.append('Set enable_assertion_pass_hook = true; remove old test __pycache__ before first capture.')
    if not entrypoint:
        errors.append('Install qa-blindspot-capture in the same Python environment used for pytest.')
    return {'version': __version__, 'config': selected, 'ready': not errors,
            'enabled': enabled, 'assertion_pass_hook': hook, 'entrypoint': entrypoint,
            'source_enabled': str(settings.get('qa_capture_sources', False)).lower() in ('true', '1', 'yes', 'on'),
            'driver_fixtures': settings.get('qa_driver_fixture', 'driver'), 'errors': errors,
            'note': 'Static check only. Device, fixture behavior and rewritten assert bytecode are verified during pytest.'}


def main(argv=None):
    parser = argparse.ArgumentParser(prog='qa-capture')
    parser.add_argument('--version', action='version', version=__version__)
    sub = parser.add_subparsers(dest='command', required=True)
    check = sub.add_parser('doctor')
    check.add_argument('--project', default='.')
    setup = sub.add_parser('init', help='Back up and configure an existing pytest project')
    setup.add_argument('--project', default='.')
    setup.add_argument('--driver-fixture', default=None)
    group = setup.add_mutually_exclusive_group()
    group.add_argument('--sources', dest='sources', action='store_true')
    group.add_argument('--no-sources', dest='sources', action='store_false')
    setup.set_defaults(sources=None)
    args = parser.parse_args(argv)
    if args.command == 'init':
        from .setup_project import initialize
        try:
            result = initialize(args.project, sources=args.sources, driver_fixture=args.driver_fixture)
            result['doctor'] = doctor(args.project)
        except (ValueError, OSError, configparser.Error) as exc:
            print(f'Setup error: {exc}')
            return 2
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result['doctor']['ready'] and not result['warnings'] else 2
    result = doctor(args.project)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['ready'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
