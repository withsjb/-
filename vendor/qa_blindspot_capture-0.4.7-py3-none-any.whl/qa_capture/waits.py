"""Finite wait grammar; inspection never invokes a customer callback or descriptor."""
from __future__ import annotations

import ast
import builtins
from pathlib import Path
from types import CodeType, FunctionType

from .semantics import selector


_STANDARD = {
    'presence_of_element_located': 'present',
    'visibility_of_element_located': 'visible',
    'invisibility_of_element_located': 'invisible',
    'text_to_be_present_in_element': 'text_contains',
}


def _bindings(method):
    result = {}
    try:
        for name, cell in zip(method.__code__.co_freevars, method.__closure__ or ()):
            result[name] = cell.cell_contents
    except ValueError:
        return None
    return result


def describe_wait(method, context):
    """Return a meaning only for library code identity or a bounded lambda AST.

    No arbitrary name/qualname matching: a customer function named like a Selenium
    condition is not trusted. Changes in Selenium closure layout fail closed.
    """
    if type(method) is not FunctionType:
        return None
    from selenium.webdriver.support import expected_conditions as EC
    cells = _bindings(method)
    if cells is None:
        return None
    for name, condition in _STANDARD.items():
        factory = getattr(EC, name, None)
        if type(factory) is not FunctionType:
            continue
        codes = [c for c in factory.__code__.co_consts if type(c) is CodeType]
        if method.__code__ not in codes or method.__globals__ is not factory.__globals__:
            continue
        locator = cells.get('locator')
        if type(locator) is not tuple or len(locator) != 2 or not all(type(v) is str for v in locator):
            return None
        target = selector(*locator, context)
        expected = cells.get('text_') if condition == 'text_contains' else True
        if not target or (condition == 'text_contains' and (type(expected) is not str or not expected or len(expected) > 20000)):
            return None
        return {'condition': condition, 'expected': expected, 'target': target,
                'locator': locator, 'grammar': name}
    return _lambda_wait(method, cells, context)


def _lambda_wait(method, cells, context):
    # Restrict to a lambda with one driver parameter. Helpers/boolean combinations,
    # transformed strings and user-defined len implementations remain unsupported.
    code = method.__code__
    if code.co_name != '<lambda>' or code.co_argcount != 1 or code.co_kwonlyargcount:
        return None
    path = Path(code.co_filename)
    try:
        if path.stat().st_size > 2000000:
            return None
        tree = ast.parse(path.read_text('utf-8'))
    except (OSError, UnicodeError, SyntaxError, ValueError):
        return None
    candidates = [n for n in ast.walk(tree) if isinstance(n, ast.Lambda) and n.lineno == code.co_firstlineno]
    if len(candidates) != 1:
        return None
    node = candidates[0]
    if not _code_matches_lambda(node, code):
        return None
    if node.args.defaults or node.args.vararg or node.args.kwarg or len(node.args.args) != 1:
        return None
    body = node.body
    if not (isinstance(body, ast.Compare) and len(body.ops) == 1 and isinstance(body.ops[0], ast.Eq)):
        return None
    driver_name = node.args.args[0].arg
    left, right = body.left, body.comparators[0]
    values = method.__globals__ | cells
    def value(expr):
        if isinstance(expr, ast.Constant) and type(expr.value) in (str, int):
            return expr.value
        if isinstance(expr, ast.Name):
            return values.get(expr.id)
        if isinstance(expr, ast.Tuple):
            vals = tuple(value(x) for x in expr.elts)
            return vals if all(type(v) is str for v in vals) else None
        # By constants are allowed only when the receiver is the actual Selenium By.
        if isinstance(expr, ast.Attribute) and isinstance(expr.value, ast.Name):
            from selenium.webdriver.common.by import By
            if values.get(expr.value.id) is By:
                return vars(By).get(expr.attr)
        return None
    if (isinstance(left, ast.Call) and isinstance(left.func, ast.Name) and left.func.id == 'len'
            and len(left.args) == 1 and not left.keywords
            and isinstance(right, ast.Constant) and type(right.value) is int and right.value == 0
            and values.get('len', builtins.len) is builtins.len
            and method.__builtins__.get('len') is builtins.len):
        query, condition, expected = left.args[0], 'absent', True
    elif isinstance(left, ast.Attribute) and left.attr == 'text':
        query, condition, expected = left.value, 'text_equals', value(right)
        if type(expected) is not str or len(expected) > 20000:
            return None
    else:
        return None
    if not (isinstance(query, ast.Call) and isinstance(query.func, ast.Attribute)
            and isinstance(query.func.value, ast.Name) and query.func.value.id == driver_name
            and query.func.attr == ('find_elements' if condition == 'absent' else 'find_element')
            and not query.keywords):
        return None
    if len(query.args) == 1 and isinstance(query.args[0], ast.Starred):
        locator = value(query.args[0].value)
    elif len(query.args) == 2:
        locator = tuple(value(a) for a in query.args)
    else:
        return None
    if type(locator) is not tuple or len(locator) != 2 or not all(type(v) is str for v in locator):
        return None
    target = selector(*locator, context)
    if not target:
        return None
    return {'condition': condition, 'expected': expected, 'target': target,
            'locator': locator, 'grammar': 'bounded_lambda'}


def _code_matches_lambda(node, original):
    """Recompile syntax without executing it to reject changed/stale source.

    Recreate only closure cell names, never their values or customer statements.
    Bytecode/constants/names must agree with the callable actually being executed.
    """
    import copy
    candidate = copy.deepcopy(node)
    bindings = [ast.Assign(targets=[ast.Name(id=name, ctx=ast.Store())], value=ast.Constant(None))
                for name in original.co_freevars]
    wrapper = ast.FunctionDef(name='_qa_capture_compare',
        args=ast.arguments(posonlyargs=[], args=[], vararg=None, kwonlyargs=[], kw_defaults=[],
                           kwarg=None, defaults=[]), body=bindings + [ast.Return(value=candidate)], decorator_list=[])
    try:
        module = ast.fix_missing_locations(ast.Module(body=[wrapper], type_ignores=[]))
        compiled = compile(module, original.co_filename, 'exec', dont_inherit=True)
        wrapper_code = next(c for c in compiled.co_consts if type(c) is CodeType)
        code = next(c for c in wrapper_code.co_consts if type(c) is CodeType and c.co_name == '<lambda>')
        return all(getattr(code, key) == getattr(original, key) for key in (
            'co_code', 'co_consts', 'co_names', 'co_varnames', 'co_freevars', 'co_cellvars',
            'co_argcount', 'co_kwonlyargcount', 'co_posonlyargcount'))
    except (SyntaxError, ValueError, TypeError, StopIteration, MemoryError, RecursionError):
        return False
