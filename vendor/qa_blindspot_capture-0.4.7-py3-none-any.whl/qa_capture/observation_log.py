"""Append-only live boundaries; no customer imports, driver calls or network use."""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import stat

import pytest


def log_path(root, output='qa-results', configured='auto'):
    if not isinstance(configured, str) or not configured.strip():
        raise ValueError('Observation log setting must be auto, off, or a file path.')
    if str(configured).lower() == 'off':
        return None
    root = Path(root).resolve()
    value = Path(output) / 'observation.log' if configured == 'auto' else Path(configured)
    path = value if value.is_absolute() else root / value
    # Do not follow links (including Windows reparse points) into other files.
    if '..' in value.parts:
        raise ValueError('Observation log must remain inside the pytest project.')
    path.relative_to(root)
    for part in (path, *path.parents):
        if part == root:
            break
        try:
            info = part.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise ValueError(f'Refusing symlink/reparse observation log: {part}')
    if path.exists() and not path.is_file():
        raise ValueError('Observation log must be a regular file.')
    return path


def prepare(path):
    if path is not None:
        path.parent.mkdir(parents=True, exist_ok=True)
        # Append mode preserves the file identity used by the live tail reader.
        with path.open('ab'):
            pass


class ObservationLog:
    def __init__(self, config, output):
        self.config = config
        self.seq = 0
        self.reports = []
        self.failed = False
        self.path = None
        # The existing qa_allure plugin owns this old option. Never register it
        # again, or write a second copy when the customer explicitly uses it.
        legacy = getattr(config.option, 'qa_observation_log', None)
        selected = config.getoption('qa_capture_observation_log') or config.getini('qa_capture_observation_log')
        self.legacy = bool(legacy)
        if legacy:
            if selected != 'auto':
                raise pytest.UsageError('Use only one observation log setting: legacy --qa-observation-log or qa_capture_observation_log.')
            self.description = f'{legacy} (existing customer log plugin)'
            return
        try:
            self.path = log_path(config.rootpath, output, selected)
            prepare(self.path)
        except (OSError, ValueError) as exc:
            self.warn(exc)
        self.description = str(self.path) if self.path and not self.failed else 'disabled'

    def warn(self, exc):
        self.failed = True
        reporter = self.config.pluginmanager.getplugin('terminalreporter')
        message = f'[QA observation log] {type(exc).__name__}: {exc}; test outcomes are unchanged.'
        if reporter:
            reporter.write_line(message, yellow=True)
        else:
            import warnings
            from pytest import PytestWarning
            # Optional log I/O must not turn a test into a failure under -W error.
            with warnings.catch_warnings():
                warnings.simplefilter('always', PytestWarning)
                warnings.warn(message, PytestWarning, stacklevel=2)

    def pytest_report_header(self):
        return f'QA observation log: {self.description}'

    def event(self, item, kind, status=''):
        if self.legacy or self.path is None or self.failed:
            return
        # One physical line per event, including parameter IDs containing whitespace.
        name = item.nodeid
        if any(c in name for c in ('\n', '\r', '\x00')) or len(name) > 500:
            self.warn(ValueError('Test node ID cannot be represented by the observation log format'))
            return
        try:
            log_path(self.config.rootpath, configured=str(self.path))
            self.seq += 1
            at = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
            line = f'{at} seq={self.seq} {kind} {name}' + (f' {status}' if status else '') + '\n'
            # Separate an existing incomplete line without truncating past records.
            with self.path.open('a+b') as stream:
                stream.seek(0, 2)
                if stream.tell():
                    stream.seek(-1, 2)
                    if stream.read(1) != b'\n':
                        stream.write(b'\n')
                stream.write(line.encode('utf-8'))
        except (OSError, ValueError) as exc:
            self.warn(exc)

    @pytest.hookimpl(hookwrapper=True, tryfirst=True)
    def pytest_runtest_protocol(self, item, nextitem):
        self.reports = []
        self.event(item, 'START')
        try:
            yield
        finally:
            if any(r.failed and r.when != 'call' for r in self.reports):
                status = 'ERROR'
            elif any(r.failed for r in self.reports):
                status = 'FAILED'
            elif any(r.skipped for r in self.reports):
                status = 'SKIPPED'
            elif any(r.when == 'call' and r.passed for r in self.reports):
                status = 'PASSED'
            else:
                status = 'ERROR'
            self.event(item, 'END', status)

    @pytest.hookimpl(hookwrapper=True)
    def pytest_runtest_makereport(self, item, call):
        outcome = yield
        self.reports.append(outcome.get_result())
