"""Local synchronous evidence collection with an intentionally limited check grammar.

No customer expressions are evaluated or executed a second time. Observation failures
are isolated from the customer's command return, exception and pytest outcome.
"""
from __future__ import annotations

import ast
from datetime import datetime, timezone, timedelta
import hashlib
import inspect
import json
from pathlib import Path
import re
import sys
import threading
import time
import uuid
import zipfile

import pytest
from . import __version__
from .semantics import assertion_shape, absence_assert, context_kind, element_id, selector
from .environment import runtime_metadata, code_metadata, device_metadata
from .waits import describe_wait
from .transition import observe_xml, xml_digest
from .storage import EvidenceStorage


_stamp_lock = threading.Lock()
_last_stamp = None


def now():
    """Preserve capture order when the host wall clock repeats a timestamp.

    The microsecond tie-break records process order, not measured clock accuracy.
    """
    global _last_stamp
    with _stamp_lock:
        value = datetime.now(timezone.utc)
        if _last_stamp is not None and value <= _last_stamp:
            value = _last_stamp + timedelta(microseconds=1)
        _last_stamp = value
        return value.isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


class Recorder:
    def __init__(self, config):
        self.started_clock = time.perf_counter()
        self.capture_seconds = 0.0
        self.wait_patch = None
        self.wait_depth = 0
        self.wait_observation = None
        self.owner_thread = None
        self.config = config
        self.root = Path(config.rootpath).resolve()
        folder = Path(config.getini('qa_capture_output'))
        if folder.is_absolute() or '..' in folder.parts:
            raise pytest.UsageError('qa_capture_output must be a project-relative folder without ..')
        self.output = self.root / folder
        try:
            self.output.resolve().relative_to(self.root)
        except ValueError:
            raise pytest.UsageError('qa_capture_output must remain inside the project.')
        self.include_sources = config.getini('qa_capture_sources')
        self.driver_names = set(config.getini('qa_driver_fixture'))
        self.hook_enabled = config.getini('enable_assertion_pass_hook')
        self.transition_ms = self._limit('qa_capture_transition_ms', 0, 3000)
        self.transition_tc_ms = self._limit('qa_capture_transition_tc_ms', 0, 10000)
        self.transition_spent = 0.0
        self.transition_seconds = 0.0
        self.max_shots = self._limit('qa_capture_max_snapshots', 1, 100)
        self.max_asset = self._limit('qa_capture_max_asset_bytes', 1024, 8000000)
        self.max_total = self._limit('qa_capture_max_total_bytes', 1024, 32000000)
        self.xml_percent = self._limit('qa_capture_xml_budget_percent', 1, 99)
        self.storage = EvidenceStorage(self.max_total, self.max_asset, self.xml_percent)
        self.run_id = uuid.uuid4().hex
        self.data = {'schema_version': '1.0', 'run': {'id': self.run_id, 'title': 'pytest QA capture',
            'started_at': now(), 'environment': {'capture': {'version': __version__,
                'source_enabled': self.include_sources, 'assertion_hook': self.hook_enabled,
                'wait_observation': True, 'settings': {'max_snapshots_per_tc': self.max_shots,
                    'max_asset_bytes': self.max_asset, 'max_total_bytes': self.max_total,
                    'xml_budget_percent': self.xml_percent,
                    'transition_ms': self.transition_ms, 'transition_tc_ms': self.transition_tc_ms,
                    'driver_fixtures': sorted(self.driver_names)}}, 'runtime': runtime_metadata(),
                'code': code_metadata(self.root), 'devices': []}},
            'test_cases': [], 'visits': [], 'snapshots': [], 'actions': [], 'checks': [],
            'sources': [], 'assertions': [], 'wait_records': [], 'limitations': [
                'pytest 수집 패키지가 보고한 자료입니다. 지원하지 않는 검증과 외부 helper는 미확인입니다.',
                '수집기의 화면 전환 관찰은 고객 검증이 아닙니다. XML 반복은 화면 준비 완료를 보장하지 않습니다.',
                '추가 관찰은 실행 타이밍에 영향을 줍니다. 시간 예산은 진행 중인 Appium 요청을 강제 중단하지 않습니다.',
                '스크린샷과 XML은 순서대로 수집하므로 동일 시점의 원자적 자료가 아닙니다.',
                '검사 목록은 항상 partial 또는 unknown이며, 기록되지 않은 검증의 부재를 뜻하지 않습니다.']}
        declared_app = {key: str(config.getini(ini)).strip()[:200] for key, ini in [('version', 'qa_app_version'), ('build', 'qa_app_build')]}
        if any(declared_app.values()):
            self.data['run']['environment']['app'] = {
                **{key: value for key, value in declared_app.items() if value},
                'metadata_source': 'declared_pytest_config',
                'missing': [key for key, value in declared_app.items() if not value]}
        self.assets = self.storage.assets
        self.asset_bytes = 0
        self.warning_counts = {}
        self.active = None
        self.item = None
        self.phase = 'setup'
        self.busy = False
        self.patches = []
        self.drivers = {}
        self.read = None
        self.state_seq = 0
        self.shot_count = 0
        self.source_id = None
        self.result_path = None
        self.syntax_cache = {}
        if not self.hook_enabled:
            self.warn('assertion_pass_hook_disabled')

    def _limit(self, name, minimum, maximum):
        try:
            value = int(self.config.getini(name))
            if not minimum <= value <= maximum:
                raise ValueError()
            return value
        except ValueError:
            raise pytest.UsageError(f'{name} must be between {minimum} and {maximum}')

    def warn(self, reason):
        if len(self.warning_counts) < 100 or reason in self.warning_counts:
            self.warning_counts[reason] = self.warning_counts.get(reason, 0) + 1

    def safe(self, method, *args):
        try:
            return method(*args)
        except Exception as exc:
            self.warn('collector_' + type(exc).__name__)
            return None

    def pytest_collection_finish(self, session):
        # session.items has already been filtered by -k/deselection.
        self.storage.case_count = max(1, len(session.items))

    def uid(self, prefix):
        return prefix + '-' + uuid.uuid4().hex

    @pytest.hookimpl(hookwrapper=True, tryfirst=True)
    def pytest_runtest_protocol(self, item, nextitem):
        self.safe(self.begin, item)
        try:
            yield
        finally:
            self.safe(self.finish)

    def begin(self, item):
        self.item = item
        self.owner_thread = threading.get_ident()
        self.phase = 'setup'
        self.read = None
        self.state_seq = 0
        self.shot_count = 0
        self.source_id = None
        callspec = getattr(item, 'callspec', None)
        parameter_id = getattr(callspec, 'id', '')
        # IDs, not arbitrary parameter values, are the customer's explicit TC mapping.
        tc_id = parameter_id if re.fullmatch(r'TC[A-Za-z0-9_\-]{1,150}', parameter_id) else 'PY_' + digest(item.nodeid.encode())[:20]
        matching = next((c for c in self.data['test_cases'] if c['tc_id'] == tc_id), None)
        if matching and matching['title'] != item.nodeid[:1000]:
            # Different test functions must not silently share a parameter-only ID.
            tc_id = 'PY_' + digest(item.nodeid.encode())[:20]
            self.warn('duplicate_tc_id_disambiguated')
        if not any(c['tc_id'] == tc_id for c in self.data['test_cases']):
            if len(self.data['test_cases']) >= 1000:
                self.active = None
                self.warn('case_quota')
                return
            self.data['test_cases'].append({'tc_id': tc_id, 'title': item.nodeid[:1000],
                'steps': '', 'expected': '', 'scope': 'in_scope', 'requirements': []})
        if len(self.data['visits']) >= 10000:
            self.active = None
            self.warn('visit_quota')
            return
        self.active = {'id': self.uid('visit'), 'tc_id': tc_id, 'result': 'unknown',
                       'checks_completeness': 'unknown', 'association': 'reported'}
        self.transition_spent = 0.0
        self.data['visits'].append(self.active)
        if self.include_sources:
            self.safe(self.capture_source, item)

    def capture_source(self, item):
        if len(self.data['sources']) >= 200 or sum(len(s['content']) for s in self.data['sources']) >= 1000000:
            self.warn('source_quota')
            return
        path = Path(item.path).resolve()
        relative = path.relative_to(self.root)
        if any(part in {'.venv', 'venv', 'site-packages', '.git', '.env'} for part in relative.parts):
            self.warn('source_path_excluded')
            return
        if path.stat().st_size > 2000000:
            self.warn('source_file_too_large')
            return
        text = path.read_text('utf-8')
        tree = ast.parse(text)
        name = getattr(item, 'originalname', None) or item.name.split('[')[0]
        line = item.obj.__code__.co_firstlineno
        nodes = [n for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
                 and n.name == name and min([n.lineno] + [d.lineno for d in n.decorator_list]) <= line <= n.end_lineno]
        if len(nodes) != 1:
            self.warn('source_function_unresolved')
            return
        node = nodes[0]
        content = ''.join(text.splitlines(keepends=True)[node.lineno-1:node.end_lineno])
        original = content
        available = min(20000, 1000000 - sum(len(s['content']) for s in self.data['sources']))
        if len(content) > available:
            content = content[:available]
        row = {'id': self.uid('source'), 'tc_id': self.active['tc_id'], 'visit_id': self.active['id'],
               'path': relative.as_posix(), 'sha256': digest(content.encode()), 'content': content,
               'start_line': node.lineno, 'end_line': node.end_lineno, 'captured_at': now(),
               'scope': 'test_function', 'truncated': content != original, 'redacted': False}
        if content != original:
            row['original_sha256'] = digest(original.encode())
        self.data['sources'].append(row)
        self.source_id = row['id']

    @pytest.hookimpl(hookwrapper=True)
    def pytest_fixture_setup(self, fixturedef, request):
        outcome = yield
        if self.active and fixturedef.argname in self.driver_names and outcome.excinfo is None:
            self.safe(self.attach, outcome.get_result())

    @pytest.hookimpl(hookwrapper=True, tryfirst=True)
    def pytest_runtest_call(self, item):
        self.phase = 'call'
        self.state_seq += 1
        for name in self.driver_names:
            if name in item.funcargs:
                self.safe(self.attach, item.funcargs[name])
        for info in list(self.drivers.values()):
            self.safe(self.capture, info)
        yield

    @pytest.hookimpl(hookwrapper=True, tryfirst=True)
    def pytest_runtest_teardown(self, item, nextitem):
        self.phase = 'teardown'
        self.state_seq += 1
        for info in list(self.drivers.values()):
            self.safe(self.capture, info)
        yield

    @pytest.hookimpl(hookwrapper=True)
    def pytest_runtest_makereport(self, item, call):
        outcome = yield
        report = outcome.get_result()
        self.safe(self.report, report, call)

    def report(self, report, call):
        if not self.active:
            return
        if report.failed:
            self.active['result'] = 'failed'
        elif report.skipped and self.active['result'] != 'failed':
            self.active['result'] = 'skipped'
        elif report.when == 'call' and report.passed and self.active['result'] == 'unknown':
            self.active['result'] = 'passed'
        if report.failed and call.excinfo and isinstance(call.excinfo.value, AssertionError):
            entries = [e for e in call.excinfo.traceback if Path(str(e.path)).resolve() == Path(item_path(self.item)).resolve()]
            if entries:
                # The failing expression was not a success-hook event. No inferred check is emitted.
                self.record_assertion(entries[-1].lineno + 1, '', 'failed', 'unresolved', [],
                                      '실패한 assert 보고; 조건·요소 연결은 자동 확정하지 않았습니다.', report.when)

    def attach(self, driver):
        if not self.active or id(driver) in self.drivers:
            return
        if not callable(getattr(driver, 'execute', None)):
            self.warn('driver_fixture_not_compatible')
            return
        original = driver.execute
        had_own = 'execute' in getattr(driver, '__dict__', {})
        own = getattr(driver, '__dict__', {}).get('execute')
        info = {'driver': driver, 'original': original, 'elements': {}, 'context': 'unknown', 'last_snapshot': None}
        # Explicitly query context once; do not dump capabilities or session credentials.
        try:
            info['context'] = context_kind(driver.current_context)
        except Exception:
            self.warn('driver_context_unknown')
        def execute(command, params=None):
            # Commands already issued by the test execute exactly once. Their exceptions are untouched.
            before = None
            if not self.busy and self.active and command in {'clickElement', 'sendKeysToElement', 'clearElement', 'goBack', 'back'}:
                before = self.safe(self.capture, info)
            observed_back = not self.busy and self.active and command in {'goBack', 'back'}
            started_at = now() if observed_back else None
            try:
                result = original(command, params)
            except Exception as exc:
                if observed_back:
                    self.safe(self.navigation, info, before, started_at, now(), 'failed')
                if not self.busy and self.active:
                    self.safe(self.wait_command_error, info, command, params or {}, exc)
                raise
            if observed_back:
                self.safe(self.navigation, info, before, started_at, now(), 'completed')
            if not self.busy and self.active:
                self.safe(self.command, info, command, params or {}, result, before)
            return result
        driver.execute = execute
        self.patches.append((driver, had_own, own, execute))
        self.drivers[id(driver)] = info
        metadata = device_metadata(driver)
        if metadata not in self.data['run']['environment']['devices']:
            self.data['run']['environment']['devices'].append(metadata)
        self.install_wait_observer()

    def navigation(self, info, before, started_at, completed_at, outcome):
        """Report the issued Back command, never a claim that the app returned home."""
        self.read = None
        self.state_seq += 1
        if len(self.data['actions']) >= 10000:
            self.warn('action_quota')
            return
        action = {'id': self.uid('action'), 'visit_id': self.active['id'], 'target': {},
                  'kind': 'back', 'at': completed_at, 'started_at': started_at,
                  'outcome': outcome, 'after_step_id': self.step(),
                  'context': info['context'], 'phase': self.phase}
        if before:
            action.update(snapshot_id=before['id'], screen_id=before['screen_id'], step_id=before['step_id'])
        self.data['actions'].append(action)

    def install_wait_observer(self):
        if self.wait_patch:
            return
        try:
            from selenium.webdriver.support.wait import WebDriverWait
            from selenium.common.exceptions import TimeoutException
        except ImportError:
            self.warn('selenium_wait_unavailable')
            return
        original = WebDriverWait.until
        recorder = self
        def until(waiter, method, message=''):
            state = getattr(waiter, '__dict__', {})
            driver = state.get('_driver') if type(state) is dict else None
            info = recorder.drivers.get(id(driver))
            if (not recorder.active or not info or info['driver'] is not driver or recorder.busy
                    or recorder.wait_depth or threading.get_ident() != recorder.owner_thread):
                return original(waiter, method, message)
            shape = recorder.safe(describe_wait, method, info['context'])
            frame = recorder.safe(recorder._customer_frame)
            try:
                location = {'line': max(1, frame.f_lineno if frame else 1)}
                if frame and recorder.include_sources:
                    try:
                        location['path'] = Path(frame.f_code.co_filename).resolve().relative_to(recorder.root).as_posix()
                    except (ValueError, OSError):
                        pass
            finally:
                del frame
            observation = {'info': info, 'shape': shape, 'state': recorder.state_seq,
                           'context': info['context'], 'query': None, 'read': None, 'error': None,
                           'visit_id': recorder.active['id'], 'tc_id': recorder.active['tc_id'], 'phase': recorder.phase}
            recorder.wait_observation = observation
            recorder.wait_depth += 1
            started = time.perf_counter()
            try:
                value = original(waiter, method, message)
            except BaseException as exc:
                status = 'timeout' if isinstance(exc, TimeoutException) else 'error'
                recorder.safe(recorder.record_wait, observation, location, started, status, None)
                raise
            else:
                recorder.safe(recorder.record_wait, observation, location, started, 'passed', value)
                return value
            finally:
                recorder.wait_depth -= 1
                recorder.wait_observation = None
                recorder.read = None  # waits cannot lend stale reads to unrelated assertions
        WebDriverWait.until = until
        self.wait_patch = (WebDriverWait, original, until)

    def observe_wait_command(self, info, command, params, value):
        observation = self.wait_observation
        if (threading.get_ident() != self.owner_thread or not observation
                or observation['info'] is not info or not observation['shape']):
            return
        if command not in {'findElement', 'findElements'}:
            return
        observation['query'] = observation['read'] = observation['error'] = None
        shape = observation['shape']
        if (params.get('using'), params.get('value')) != shape['locator']:
            return
        if command == 'findElement':
            identity = element_id(value)
            if type(identity) is str:
                observation['query'] = {'identity': identity, 'count': 1}
        elif type(value) is list:
            observation['query'] = {'identity': None, 'count': len(value)}

    def observe_wait_read(self, info, condition, identity, value):
        observation = self.wait_observation
        if (threading.get_ident() != self.owner_thread or not observation
                or observation['info'] is not info or not observation['query']):
            return
        if identity == observation['query']['identity']:
            observation['read'] = {'condition': condition, 'actual': value}

    def wait_command_error(self, info, command, params, exc):
        observation = self.wait_observation
        if (threading.get_ident() != self.owner_thread or not observation
                or observation['info'] is not info or not observation['shape']):
            return
        from selenium.common.exceptions import NoSuchElementException
        observation['read'] = None
        observation['error'] = type(exc).__name__
        if (command == 'findElement' and isinstance(exc, NoSuchElementException)
                and (params.get('using'), params.get('value')) == observation['shape']['locator']):
            observation['query'] = {'identity': None, 'count': 0}
            observation['error'] = 'missing'
        else:
            observation['query'] = None

    def record_wait(self, observation, location, started, status, value):
        if not self.active:
            return
        if len(self.data['wait_records']) >= 10000:
            self.warn('wait_record_quota')
            return
        duration_ms = max(0, round((time.perf_counter() - started) * 1000))
        shape, info = observation['shape'], observation['info']
        row = {'id': self.uid('wait'), 'tc_id': observation['tc_id'], 'visit_id': observation['visit_id'],
               'phase': observation['phase'], 'at': now(), 'duration_ms': duration_ms, 'status': status,
               'interpretation': 'unsupported' if not shape else 'unresolved', 'check_ids': [], **location,
               'reason': '지원하지 않는 대기 조건입니다. 임의 콜백을 다시 실행하거나 검사로 추정하지 않습니다.'}
        self.data['wait_records'].append(row)
        same_scope = (observation['visit_id'] == self.active['id'] and observation['phase'] == self.phase
                      and observation['state'] == self.state_seq and observation['context'] == info['context'] != 'unknown')
        if shape:
            row['condition'] = shape['condition']
            if same_scope:
                row.update(target=shape['target'], expected=shape['expected'],
                           screen_id=f'state-{observation["visit_id"][-12:]}-{observation["state"]}',
                           context=observation['context'], step_id=f'{observation["phase"]}-state-{observation["state"]}')
        if status != 'passed':
            row['reason'] = ('대기 시간이 초과됐습니다. 이 예외를 테스트가 처리했는지와 TC 결과는 별도로 확인하세요.'
                             if status == 'timeout' else '대기 중 예외가 발생했습니다. 원래 예외와 TC 결과는 변경하지 않았습니다.')
            return
        if not shape:
            return
        condition, expected = shape['condition'], shape['expected']
        query, read = observation['query'], observation['read']
        actual = None
        if same_scope and query:
            if condition == 'present' and query['identity'] and element_id(value) == query['identity']:
                actual = True
            elif condition == 'absent' and query['count'] == 0 and value is True:
                actual = True
            elif condition == 'invisible' and (
                    (query['count'] == 0 and observation['error'] == 'missing' and value is True)
                    or (read and read['condition'] == 'visible' and read['actual'] is False)):
                actual = True
            elif condition == 'visible' and read and read['condition'] == 'visible' and read['actual'] is True:
                actual = True
            elif condition in {'text_equals', 'text_contains'} and read and read['condition'] == 'text_equals':
                text = read['actual']
                if type(text) is str and ((condition == 'text_equals' and text == expected)
                                         or (condition == 'text_contains' and expected in text)):
                    actual = text
        if actual is None:
            row['reason'] = '대기는 완료됐지만 같은 드라이버·구간의 지원되는 읽기 결과와 의미 연결을 확인하지 못했습니다.'
            return
        if len(self.data['checks']) >= 10000:
            self.warn('check_quota')
            return
        snap = self.capture(info)
        check = {'id': self.uid('check'), 'visit_id': self.active['id'], 'target': shape['target'],
                 'screen_id': snap['screen_id'] if snap else f'state-{self.active["id"][-12:]}-{self.state_seq}',
                 'condition': condition, 'expected': expected, 'actual': actual, 'result': 'passed',
                 'origin': 'reported', 'context': info['context'], 'at': now(), 'phase': self.phase, 'step_id': self.step()}
        if snap:
            check['snapshot_id'] = snap['id']
        self.data['checks'].append(check)
        self.active['checks_completeness'] = 'partial'
        row.update(interpretation='supported', check_ids=[check['id']],
                   reason='지원되는 until 조건과 같은 드라이버·구간의 읽기 결과를 연결했습니다. 콜백을 추가 실행하지 않았습니다.')

    def _customer_frame(self):
        frame = sys._getframe(1)
        try:
            while frame:
                filename = frame.f_code.co_filename
                try:
                    path = Path(filename).resolve()
                    path.relative_to(self.root)
                    if not any(part in {'.venv', 'venv', 'site-packages'} for part in path.parts):
                        return frame
                except (ValueError, OSError):
                    pass
                frame = frame.f_back
        finally:
            del frame
        return None

    def command(self, info, command, params, result, before=None):
        value = result.get('value') if isinstance(result, dict) else None
        if command in {'switchToContext', 'switchToWindow'}:
            info['context'] = context_kind(params.get('name')) if command == 'switchToContext' else 'unknown'
            info['elements'].clear()
            self.read = None
            self.state_seq += 1
        self.observe_wait_command(info, command, params, value)
        if command in {'findElement', 'findElements'}:
            self.read = None
            target = selector(params.get('using'), params.get('value'), info['context'])
            values = value if isinstance(value, list) else [value]
            if target:
                for element in values[:500]:
                    identity = element_id(element)
                    if isinstance(identity, str):
                        info['elements'][identity] = target
            if command == 'findElements' and target and type(value) is list:
                customer = self._customer_frame()
                try:
                    self.read = {'condition': 'absent', 'actual': len(value) == 0, 'target': target,
                        'frame_id': id(customer), 'code': customer.f_code if customer else None,
                        'line': customer.f_lineno if customer else 0, 'info': info, 'context': info['context'],
                        'state': self.state_seq, 'phase': self.phase}
                finally:
                    del customer
            return
        condition = {'isElementDisplayed': 'visible', 'isElementEnabled': 'enabled', 'getElementText': 'text_equals'}.get(command)
        identity = params.get('id')
        # Selenium implements is_displayed by its own JS atom. Recognize the library
        # method frame, never arbitrary customer execute_script return values.
        if command in {'w3cExecuteScript', 'executeScript'}:
            frame = sys._getframe(1)
            while frame:
                module = frame.f_globals.get('__name__', '')
                if module.startswith('selenium.webdriver.') and frame.f_code.co_name == 'is_displayed':
                    condition = 'visible'
                    identity = element_id(frame.f_locals.get('self'))
                    break
                frame = frame.f_back
        if condition:
            self.observe_wait_read(info, condition, identity, value)
            customer = self._customer_frame()
            try:
                self.read = {'condition': condition, 'actual': value, 'target': info['elements'].get(identity),
                    'frame_id': id(customer), 'code': customer.f_code if customer else None,
                    'line': customer.f_lineno if customer else 0, 'info': info, 'context': info['context'],
                    'state': self.state_seq, 'phase': self.phase}
            finally:
                del customer
        mutation = command in {'clickElement', 'sendKeysToElement', 'clearElement', 'goBack', 'back',
            'goForward', 'get', 'refresh', 'touchPerform', 'multiAction', 'actions', 'clearActionState',
            'executeAsyncScript', 'w3cExecuteScriptAsync', 'activateApp', 'terminateApp', 'launchApp',
            'closeApp', 'reset', 'setOrientation', 'pressKeyCode', 'longPressKeyCode'}
        # Arbitrary JS/mobile scripts may mutate the UI. The known Selenium visibility
        # atom above is the only synchronous script that can supply a read check.
        mutation = mutation or (command in {'w3cExecuteScript', 'executeScript'} and not condition)
        if mutation:
            self.read = None
            if command not in {'goBack', 'back'}:
                self.state_seq += 1
            self.capture(info)
            if command in {'clickElement', 'goBack', 'back'}:
                self.safe(self.observe_transition, info, before)
            target = info['elements'].get(identity)
            if target and command in {'clickElement', 'sendKeysToElement', 'clearElement'} and len(self.data['actions']) < 10000:
                action = {'id': self.uid('action'), 'visit_id': self.active['id'], 'target': target,
                          'kind': 'click' if command == 'clickElement' else 'input', 'at': now(),
                          'context': info['context'], 'phase': self.phase}
                if before:
                    action.update(snapshot_id=before['id'], screen_id=before['screen_id'], step_id=before['step_id'])
                self.data['actions'].append(action)

    def observe_transition(self, info, before):
        if self.phase != 'call' or not self.transition_ms:
            return
        remaining = self.transition_tc_ms / 1000 - self.transition_spent
        if remaining <= 0:
            self.warn('transition_tc_budget')
            return
        if self.shot_count >= self.max_shots:
            self.warn('transition_capture_quota')
            return
        raw = self.assets.get((before or {}).get('xml_path'), b'')
        baseline = xml_digest(raw.decode('utf-8')) if raw else None
        started = time.perf_counter()
        self.busy = True
        try:
            result = observe_xml(lambda: info['driver'].page_source, baseline,
                                 min(self.transition_ms / 1000, remaining))
        finally:
            self.busy = False
            self.transition_spent += time.perf_counter() - started
            self.transition_seconds += time.perf_counter() - started
        # Capture even unchanged XML: lack of a visible transition is not success.
        snap = self.capture(info) if result['reads'] else None
        result.update(tc_id=self.active['tc_id'], visit_id=self.active['id'],
                      step_id=self.step(), snapshot_id=snap['id'] if snap else None)
        events = self.data['run']['environment']['capture'].setdefault('transition_observations', [])
        if len(events) < 1000:
            events.append(result)
        if result['status'] != 'changed_then_repeated_xml':
            self.warn('transition_not_confirmed')
        if snap is None:
            self.warn('transition_capture_missing')

    def step(self):
        return f'{self.phase}-state-{self.state_seq}'

    def capture(self, info):
        if self.busy or not self.active:
            return None
        if self.shot_count >= self.max_shots or len(self.data['snapshots']) >= 900:
            self.warn('snapshot_quota')
            return None
        self.shot_count += 1
        capture_started = time.perf_counter()
        self.busy = True
        row = {'id': self.uid('snapshot'), 'tc_id': self.active['tc_id'], 'visit_id': self.active['id'],
               'screen_id': f'state-{self.active["id"][-12:]}-{self.state_seq}', 'context': info['context'],
               'association': 'reported', 'at': now(), 'phase': self.phase, 'step_id': self.step()}
        try:
            driver = info['driver']
            try:
                xml = driver.page_source
                if type(xml) is str:
                    raw = xml.encode('utf-8')
                    self.asset(row, 'xml_path', 'xml', raw)
                else:
                    self.missing_asset(row, 'xml', 'xml_invalid')
            except Exception:
                self.missing_asset(row, 'xml', 'xml_unavailable')
            try:
                image = driver.get_screenshot_as_png()
                if type(image) is bytes and image.startswith(b'\x89PNG\r\n\x1a\n'):
                    self.asset(row, 'image_path', 'png', image)
                else:
                    self.missing_asset(row, 'image', 'screenshot_invalid')
            except Exception:
                self.missing_asset(row, 'image', 'screenshot_unavailable')
            if 'image_path' not in row and 'xml_path' not in row:
                return None
            self.data['snapshots'].append(row)
            info['last_snapshot'] = row
            return row
        finally:
            self.capture_seconds += time.perf_counter() - capture_started
            self.busy = False

    def asset(self, row, key, suffix, data):
        path, reason = self.storage.save(row, suffix, data)
        self.asset_bytes = self.storage.total_bytes
        if reason:
            self.warn(reason)
        if path:
            row[key] = path

    def missing_asset(self, row, kind, reason):
        self.storage.reject(row, kind, reason)
        self.warn(reason)

    def pytest_assertion_pass(self, item, lineno, orig, expl):
        self.safe(self.assertion_pass, item, lineno, orig)

    def standalone_assert(self, code, line):
        """Reject two statements on one line: a preceding read is not assert evidence."""
        path = Path(code.co_filename).resolve()
        if path != Path(item_path(self.item)).resolve():
            return False
        if path not in self.syntax_cache:
            if path.stat().st_size > 2000000:
                return False
            self.syntax_cache[path] = ast.parse(path.read_text('utf-8'))
        statements = [n for n in ast.walk(self.syntax_cache[path])
                      if isinstance(n, ast.stmt) and n.lineno == line]
        return len(statements) == 1 and isinstance(statements[0], ast.Assert)

    def assertion_pass(self, item, lineno, expression):
        if not self.active or self.phase != 'call':
            return
        read = self.read
        self.read = None  # no later assert may borrow this observation
        frame = sys._getframe(1)
        match = None
        try:
            while frame:
                if read and id(frame) == read['frame_id'] and frame.f_code is read['code'] and frame.f_lineno == lineno:
                    match = frame
                    break
                frame = frame.f_back
            shape = assertion_shape(expression, match) if match else None
            standalone = bool(read and read['code'] and self.standalone_assert(read['code'], lineno))
            absence = bool(match and standalone and absence_assert(
                self.syntax_cache[Path(read['code'].co_filename).resolve()], match, lineno, read))
            if absence:
                shape = ('absent', True)
            valid = (shape and read and (read['line'] == lineno or absence) and read['phase'] == self.phase
                     and read['state'] == self.state_seq and read['target'] and shape[0] == read['condition']
                     and read['context'] != 'unknown' and standalone)
            if not valid:
                self.record_assertion(lineno, expression, 'passed', 'unresolved', [],
                                      '지원 문법 또는 동일 실행 프레임·줄의 요소 읽기 연결을 확인하지 못했습니다.')
                return
            condition, expected = shape
            actual = read['actual']
            # Only actual primitive results are trusted, not arbitrary truthy objects.
            if (condition == 'text_equals' and (type(actual) is not str or actual != expected)) or (
                    condition != 'text_equals' and (type(actual) is not bool or actual is not True)):
                self.record_assertion(lineno, expression, 'passed', 'unresolved', [], '읽기 값과 assert 성공 의미가 일치하지 않습니다.')
                return
            if len(self.data['checks']) >= 10000:
                self.warn('check_quota')
                return
            snap = self.capture(read['info'])
            check = {'id': self.uid('check'), 'visit_id': self.active['id'], 'target': read['target'],
                'screen_id': snap['screen_id'] if snap else f'state-{self.active["id"][-12:]}-{self.state_seq}',
                'condition': condition, 'expected': expected, 'actual': actual, 'result': 'passed',
                'origin': 'reported', 'context': read['context'], 'at': now(), 'phase': self.phase, 'step_id': self.step()}
            if snap:
                check['snapshot_id'] = snap['id']
            self.data['checks'].append(check)
            self.active['checks_completeness'] = 'partial'
            self.record_assertion(lineno, expression, 'passed', 'supported', [check['id']],
                                  '지원되는 assert 문법과 같은 실행 프레임의 WebDriver 읽기를 연결했습니다.')
        finally:
            del frame, match

    def record_assertion(self, line, expression, status, interpretation, check_ids, reason, phase=None):
        if len(self.data['assertions']) >= 10000:
            self.warn('assertion_quota')
            return
        row = {'id': self.uid('assertion'), 'tc_id': self.active['tc_id'], 'visit_id': self.active['id'],
               'status': status, 'line': max(1, line), 'check_ids': check_ids, 'interpretation': interpretation,
               'reason': reason, 'phase': phase or self.phase, 'at': now()}
        if self.include_sources:
            if expression:
                row['expression'] = expression[:2000]
            source = next((s for s in self.data['sources'] if s['id'] == self.source_id), None)
            if source and source['start_line'] <= line <= source['end_line']:
                row['source_id'] = source['id']
        self.data['assertions'].append(row)

    def finish(self):
        if self.wait_patch:
            wait_class, original, installed = self.wait_patch
            if wait_class.until is installed:
                wait_class.until = original
            else:
                self.warn('wait_restore_owner_changed')
            self.wait_patch = None
        self.wait_observation = None
        self.wait_depth = 0
        for driver, had_own, own, installed in reversed(self.patches):
            try:
                if getattr(driver, '__dict__', {}).get('execute') is installed:
                    if had_own:
                        driver.execute = own
                    else:
                        del driver.execute
            except Exception:
                self.warn('driver_restore_failed')
        self.patches.clear()
        self.drivers.clear()
        if self.active:
            visit_id = self.active['id']
            if self.active['result'] == 'passed' and not any(a['visit_id'] == visit_id for a in self.data['assertions']) and not any(w['visit_id'] == visit_id and w['interpretation'] == 'supported' for w in self.data['wait_records']):
                self.warn('passed_tc_without_assertion_events_hook_or_cache_unconfirmed')
                self.active['notes'] = 'assert 기록이 없습니다. 검사 부재를 뜻하지 않습니다. 훅 설정·기존 pyc·rewrite 대상 여부를 확인하세요.'
        self.read = None
        self.active = None
        self.item = None

    def pytest_sessionfinish(self, session, exitstatus):
        self.safe(self.finish)
        self.safe(self.export)

    def export(self):
        self.data['run']['finished_at'] = now()
        metadata = self.data['run']['environment']['capture']
        metadata['storage'] = self.storage.summary()
        metadata.update(warnings=dict(self.warning_counts), truncation=bool(self.warning_counts), metrics={
            'duration_seconds': round(time.perf_counter() - self.started_clock, 6),
            'capture_seconds': round(self.capture_seconds, 6),
            'transition_observation_seconds': round(self.transition_seconds, 6), 'snapshot_count': len(self.data['snapshots']),
            'asset_bytes': self.asset_bytes, 'deduplicated_bytes': self.storage.saved_bytes, 'wait_count': len(self.data['wait_records'])})
        descriptions = {
            'transition_not_confirmed': '추가 관찰에서 XML 변화 후 반복을 확인하지 못한 구간이 있습니다. 화면 전환 실패나 검증 누락을 뜻하지 않습니다.',
            'transition_tc_budget': 'TC별 추가 관찰 시간 예산을 소진한 구간이 있습니다. 이후 중간 화면 근거는 부족할 수 있습니다.',
            'transition_capture_quota': '캡처 또는 용량 한도로 클릭 후 추가 화면 관찰을 생략했습니다.',
            'transition_capture_missing': '추가 관찰 후 화면 근거를 저장하지 못했습니다.',
        }
        descriptions.update({
            'image_tc_quota': 'TC별 사진 저장 한도에 도달했습니다. XML 예산은 별도로 유지됩니다.',
            'xml_tc_quota': 'TC별 XML 저장 한도에 도달했습니다. 해당 구간은 XML 근거가 부족할 수 있습니다.',
            'image_pool_quota': '실행 전체 사진 저장 한도에 도달했습니다. XML 예산은 별도로 유지됩니다.',
            'xml_pool_quota': '실행 전체 XML 저장 한도에 도달했습니다.',
        })
        for entry in metadata['storage']['omission_counts']:
            steps = sorted({event['step_id'] for event in self.storage.omissions
                            if event['visit_id'] == entry['visit_id']
                            and event['kind'] == entry['kind'] and event['reason'] == entry['reason']})
            self.data['limitations'].append(
                f"수집 누락: {entry['tc_id']} · {'XML' if entry['kind'] == 'xml' else '사진'} · "
                f"{entry['count']}회 · {entry['reason']} · 구간: {', '.join(steps[:6])}")
        for key in self.warning_counts:
            self.data['limitations'].append('수집 진단: ' + key + (' — ' + descriptions[key] if key in descriptions else ''))
        manifest = json.dumps(self.data, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
        # Do not emit an archive the analyzer cannot import. Drop optional sources first.
        if len(manifest) > 8000000:
            self.data['sources'] = []
            for assertion in self.data['assertions']:
                assertion.pop('source_id', None)
                assertion.pop('expression', None)
            self.warn('manifest_source_omitted')
            manifest = json.dumps(self.data, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
        if len(manifest) > 8000000:
            self.warn('manifest_quota_export_skipped')
        self.output.mkdir(parents=True, exist_ok=True)
        diagnosis = {'run_id': self.run_id, 'warnings': self.warning_counts,
                    'tc_count': len(self.data['test_cases']), 'visit_count': len(self.data['visits']),
                    'snapshot_count': len(self.data['snapshots']), 'check_count': len(self.data['checks']),
                    'assertion_count': len(self.data['assertions']), 'source_count': len(self.data['sources']),
                    'wait_count': len(self.data['wait_records']), 'metrics': metadata['metrics'],
                    'storage': metadata['storage'], 'exported': len(manifest) <= 8000000}
        (self.output / (self.run_id + '.diagnostics.json')).write_text(json.dumps(diagnosis, ensure_ascii=False, indent=2), 'utf-8')
        if len(manifest) > 8000000:
            return
        path = self.output / (self.run_id + '.zip')
        temporary = path.with_suffix('.zip.tmp')
        try:
            with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_STORED) as archive:
                archive.writestr('manifest.json', manifest)
                for name, content in self.assets.items():
                    archive.writestr(name, content)
            temporary.replace(path)
            self.result_path = path
            diagnosis['archive_bytes'] = path.stat().st_size
            (self.output / (self.run_id + '.diagnostics.json')).write_text(json.dumps(diagnosis, ensure_ascii=False, indent=2), 'utf-8')
        finally:
            temporary.unlink(missing_ok=True)

    def pytest_terminal_summary(self, terminalreporter):
        if self.result_path:
            terminalreporter.write_line(f'[QA capture] 결과: {self.result_path}')
        else:
            terminalreporter.write_line('[QA capture] 결과 ZIP을 저장하지 못했습니다. 출력 경로와 수집 진단을 확인하세요.', yellow=True)
        if self.warning_counts:
            terminalreporter.write_line('[QA capture] 진단: ' + ', '.join(sorted(self.warning_counts)), yellow=True)


def item_path(item):
    return str(item.path) if item else ''
